﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kupaApp
{
   
    public partial class Form1 : Form
    {
        int iloscKup;
        int wszystkieKupy;
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
  
            progressBar1.Increment(20);

                if (progressBar1.Value == 100)
                {
                    label1.Text = "GRATULUJE! \nMożesz robić jeszcze raz!";
                    KUPA.Enabled = false;
                    iloscKup++;
                    wszystkieKupy++;
                    label3.Text = "Ilość kup: " + iloscKup.ToString();
                }
                else
                {
                    label1.Text = "ROBISZ KUPE";
                }
                label2.Text = progressBar1.Value.ToString() + " %";

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (progressBar1.Value != 100)
            {
                label1.Text = "NIE MOZESZ ZACZAC NOWEJ KUPY \n JAK NIE SKONCZYLES WCZESNIEJSZEJ!";
            }
            else if (iloscKup >= 2)
            {
                label1.Text = "ZA DUŻO KUPY! \nUŻYJ SPŁUCZKI";
            }
            else
            {
                progressBar1.Value = 0;
                label2.Text = progressBar1.Value.ToString() + " %";
                label1.Text = "KLIKNIJ BUTTON";
                KUPA.Enabled = true;
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            iloscKup = 0;
            label3.Text = "Ilość kup: " + iloscKup.ToString();
            label1.Text = "UŻYŁEŚ SPŁUCZKI";
            KUPA.Enabled = true;
            progressBar1.Value = 0;
            label2.Text = progressBar1.Value.ToString() + " %";
            if(wszystkieKupy > 3)
            {
                label1.Text = "WYPADAŁO BY SIE PODETRZEC";
            }
        }
    }
}
